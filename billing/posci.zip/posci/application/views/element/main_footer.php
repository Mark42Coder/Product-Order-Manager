
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
     - CodeIgniter
    </div>
    <!-- Default to the left -->
    <strong> &copy; <?php echo date("Y"); ?> Point Of Sale System </strong> 
  </footer>