    <!-- jQuery -->
    <script src="<?=base_url();?>libs/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url();?>libs/bootstrap/dist/js/bootstrap.min.js"></script>
	
	<!-- Bootstrap Toggle JavaScript -->
	<script src="<?=base_url();?>libs/bootstrap-toggle/dist/js/bootstrap-toggle.min.js"></script>
	
	<!-- Pace -->
    <script src="<?=base_url();?>libs/pace/dist/pace.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="libs/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables Javascript -->
    <script src="<?=base_url();?>libs/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?=base_url();?>libs/datatables/media/js/dataTables.tableTools.js"></script>
    <script src="<?=base_url();?>libs/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom JavaScript -->
    <script src="assets/js/script.js"></script>

    <!-- Test Javascript  -->
    <script src="<?=base_url();?>libs/test/test.js"></script>
	
	<!-- Chosen  -->
	<script src="<?=base_url();?>libs/chosen/chosen.jquery.js" type="text/javascript"></script>
	
	<!-- JSON2 -->
	<script src="<?=base_url();?>libs/json2/json2.js" type="text/javascript"></script>