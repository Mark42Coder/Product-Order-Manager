###################
What is Kandi Inventory
###################
Kandi Inventory is a very simple and accurate inventory which can be used for any shop. 
Their are still many features remaining
but for now, it can be used and any one can customized it for their needs.

UPCOMING FEATURES: 

Database Backup (Done)
Sales Return (Done)
Purchase Return
Profit & Loss Statement


##########################
YOUTUBE LINK 
############################
https://youtu.be/ycCV66xzqY8


Note: if you have any question, feel free to ask. 
Email: shahmian@gmail.com
Website: http://phptiger.com
